</div>
<footer class="bg-white sticky-footer" id="footer">
    <div class="container my-auto">
        <div class="text-end my-auto copyright" style="padding-bottom: 10px;"><img id="shop_logo" src="assets/img/13e7bddc-3c00-45ff-b8a4-84901b6e9b80.png"></div>
        <div class="text-center my-auto copyright" style="margin-right: 0px;margin-left: 20px;"><span class="text-end" style="direction: rtl;float: right;line-height: 20px;letter-spacing: 1px;color: var(--bs-dark);">تلفن پشتیبانی:xxxxxxxxxxهفت روز هفته، ۲۴ ساعت شبانه‌روز پاسخگوی شما هستیم .<br></span></div>
        <div class="d-none d-sm-none d-md-inline-flex d-lg-inline-flex d-xl-inline-flex d-xxl-inline-flex justify-content-center copyright" style="text-align: center;margin-top: 20px;"><span class="d-flex justify-content-center align-items-center align-content-center align-self-center" style="direction: rtl;float: right;text-align: center;line-height: 23.8px;font-size: 10px;margin-right: 0px;margin-left: 20px;">امکان تحویل اکسپرس<br><img src="https://www.digikala.com/static/files/8f570b58.svg" width="25%" style="padding-right: 5px;"></span><span class="d-flex justify-content-center align-items-center align-content-center align-self-center" style="direction: rtl;float: right;text-align: center;line-height: 23.8px;font-size: 10px;margin-right: 0px;margin-left: 20px;">امکان پرداخت در محل<br><img src="https://www.digikala.com/static/files/22414818.svg" width="25%" style="padding-right: 5px;"></span><span class="d-flex justify-content-center align-items-center align-content-center align-self-center" style="direction: rtl;float: right;text-align: center;line-height: 23.8px;font-size: 10px;margin-right: 0px;margin-left: 20px;">۷ روز هفته، ۲۴ ساعته<br><img src="	https://www.digikala.com/static/files/a9286d2f.svg" width="25%" style="padding-right: 5px;"></span><span class="d-flex justify-content-center align-items-center align-content-center align-self-center" style="direction: rtl;float: right;text-align: center;line-height: 23.8px;font-size: 10px;margin-right: 0px;margin-left: 20px;">۷ روز ضمانت بازگشت کالا<br><img src="https://www.digikala.com/static/files/514926b1.svg" width="25%" style="padding-right: 5px;"></span><span class="d-flex justify-content-center align-items-center align-content-center align-self-center" style="direction: rtl;float: right;text-align: center;line-height: 23.8px;font-size: 10px;margin-right: 0px;margin-left: 20px;">ضمانت اصل بودن کالا<br><img src="	https://www.digikala.com/static/files/fdb293e6.svg" width="25%" style="padding-right: 5px;"></span></div>
        <div class="text-center d-flex d-sm-flex d-md-flex d-lg-flex d-xl-flex d-xxl-flex my-auto justify-content-md-end copyright" style="padding-bottom: 10px;padding-top: 10px;width: 100%;">
            <div class="text-end d-grid" style="width: 514.047px;margin-right: 0px;margin-left: 30px;">
                <h1 style="text-align: right;font-size: 17px;color: var(--bs-gray-dark);"><strong>شبکه های اجتماعی ما</strong><br></h1><a class="d-sm-flex d-lg-flex justify-content-sm-end align-items-sm-center justify-content-lg-end align-items-lg-center" href="#" style="color: var(--bs-gray-dark);padding: 10px;">اینستاگرام&nbsp;<i class="fa fa-instagram" style="margin-left: 10px;font-size: 18.8px;color: #ef394e;"></i></a><a class="d-sm-flex d-lg-flex justify-content-sm-end align-items-sm-center justify-content-lg-end align-items-lg-center" href="#" style="color: var(--bs-gray-dark);padding: 10px;">توییتر<i class="fa fa-twitter" style="margin-left: 10px;font-size: 18.8px;color: var(--bs-blue);"></i></a><a class="d-sm-flex d-lg-flex justify-content-sm-end align-items-sm-center justify-content-lg-end align-items-lg-center" href="#" style="color: var(--bs-gray-dark);padding: 10px;">تلگرام<i class="fa fa-telegram" style="margin-left: 10px;font-size: 18.8px;color: rgb(0,188,226);"></i></a>
            </div>
            <div class="text-end d-grid" style="width: 514.047px;margin-right: 0px;margin-left: 30px;">
                <h1 style="text-align: right;font-size: 17px;color: var(--bs-gray-dark);"><strong>ارتباط با ما</strong></h1><a class="d-lg-flex justify-content-lg-end align-items-lg-center" href="#" style="color: var(--bs-gray-dark);padding: 10px;">اتاق اخبار</a><a class="d-lg-flex justify-content-lg-end align-items-lg-center" href="#" style="color: var(--bs-gray-dark);padding: 10px;">تماس با ما</a><a class="d-lg-flex justify-content-lg-end align-items-lg-center" href="#" style="color: var(--bs-gray-dark);padding: 10px;">درباره ما</a>
            </div>
        </div>
        <hr>
        <div class="text-center d-md-flex flex-sm-column-reverse flex-md-column-reverse flex-lg-row copyright" style="padding-bottom: 10px;padding-top: 10px;overflow: hidden;">
            <div class="d-flex" style="margin-left: 17px;margin-top: 10px;margin-right: 10px;">
                <div class="d-lg-flex justify-content-lg-center align-items-lg-center" style="width: 120px;height: 120px;border-radius: 15px;border-style: solid;border-color: rgba(246,194,62,0.1);margin-left: 17px;"><img src="https://www.digikala.com/static/files/6e2d6b38.png"></div>
                <div class="d-lg-flex justify-content-lg-center align-items-lg-center" style="width: 120px;height: 120px;border-radius: 15px;border-style: solid;border-color: rgba(246,194,62,0.1);margin-left: 17px;"><img src="https://www.digikala.com/static/files/236e437c.png"></div>
                <div class="d-lg-flex justify-content-lg-center align-items-lg-center" style="width: 120px;height: 120px;border-radius: 15px;border-style: solid;border-color: rgba(246,194,62,0.1);margin-left: 17px;"><img src="	https://www.digikala.com/static/files/3a24ea39.png"></div>
            </div>
            <div style="margin: 10px;">
                <h1 style="font-size: 17px;text-align: right;color: var(--bs-warning);"><strong>فروشگاه اینترنتی ..... ، بررسی، انتخاب و خرید آنلاین</strong><br></h1><span style="direction: rtl;float: right;line-height: 20px;letter-spacing: 1px;color: var(--bs-gray-dark);text-align: justify;">فروشگاه اینترنتی ......&nbsp;<br></span>
            </div>
        </div>
        <hr>
        <div class="text-center my-auto copyright" style="margin-top: 10px;margin-bottom: 10px;"><span>online shop © Vista 2021</span></div>
    </div>
</footer>
</div>
<a class="border rounded d-inline scroll-to-top" href="#page-top" style="background: rgba(90,92,105,0.45);"><i class="fas fa-angle-up" style="color: var(--bs-yellow);"></i></a>
</div>
<script src="assets/bootstrap/js/bootstrap.min.js"></script>
<script src="assets/js/home_header_slider.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/6.4.8/swiper-bundle.min.js"></script>
<script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/logo.js"></script>
<script src="assets/js/mini%20p%20image%20slider.js"></script>
<script src="assets/js/new_p_vs.js"></script>
<script src="assets/js/productslider.js"></script>
<script src="assets/js/Simple-Slider.js"></script>
<script src="assets/js/theme.js"></script>
<script src="extrajs.js"></script>
<script>
    //var cart_badge_item_num = '<?php //echo Count_User_cart_item();?>//';
    var user_login_state = '<?php echo user_login_state() ;?>';
    if (user_login_state == 0) {
        $('#notloginpart').css('display', 'inline');
        //$('#loginpart').css('display','none');
    } else {
        //$('#notloginpart').css('display','none');
        $('#loginpart').css('display', 'inline');
        $('#header_userfname').text(user_login_state + ' خوش آمدید ')
        $('#profile_userfname').text(user_login_state + ' خوش آمدید ')
    }
</script>


</body>

</html>


