# online-shop
see demo : 

Sections: 
  <br>Home page
  <br>Product features screen and order 
  <br>Shopping Cart Page
  <br>Search and filter products 
  <br>Registration page and user profile 
  <br>Admin page
