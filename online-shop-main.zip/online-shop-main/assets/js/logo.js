document.getElementById("shop_logo").addEventListener("click", myFunction);
function myFunction() {
  window.location.href = "index.html";
}

// function myFunction() {
//     alert('s');
//     //window.location.href = "http://www.w3schools.com";
// }
