var swiper = new Swiper(".new-product-vslid", {
        direction: "vertical",
        centeredSlides: true,
        grabCursor: true,
        loop: true,
        pagination: {
          el: ".swiper-pagination",
          clickable: true,
        },
      });